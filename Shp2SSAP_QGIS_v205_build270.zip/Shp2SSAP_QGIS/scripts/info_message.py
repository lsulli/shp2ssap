from qgis.PyQt.QtWidgets import QMessageBox

def _xy_info():
	"""UI slot: show a short help for the XY tab."""
	msg = (
		"Formato atteso (un punto per riga):\n"
		"  X  Y\n"
		"  oppure X;Y oppure X,Y (separatore spazio/;/,)\n\n"
		"Esempio:\n"
		"  12.345 45.678\n"
		"  12.346 45.679\n\n"
		"Si può anche incollare i punti dalla clipboard (pulsante Input clipboard)."
	)
	QMessageBox.information( None, "XY → Shapefile (aiuto)", msg)

def _bd_fld_info():
	"""UI slot: show a short help for the bedrock and fld layers """
	msg = (
		"Crea uno strato di base (bedrock) con resistenza elevata alla profondità indicata.\n"
		"Imposta nello Shapefile SSAP = dat e SSAP_ID = 2\n\n"
		"Crea il layer falda alla profondità indicata.\n"
		"Imposta nello Shapefile SSAP = fld e SSAP_ID = 0\n"
	)
	QMessageBox.information(None, "XY → Shapefile (aiuto)", msg)

def _ba_info():
	"""UI slot: show a short help for back analysis """
	msg = (
		"Crea un modello semplificato utile ad impostare una verifica in back analysis.\n"
		"Impone un angolo d'attrito pari a pendenza media del pendio\n"
		"e coesione nulla (condizioni residue).\n\n"
	)
	QMessageBox.information(None, "XY → Shapefile (aiuto)", msg)

def _simp_info():
	"""UI slot: show a short help for back analysis """
	msg = (
		"Semplifica tutte le polyline del layer riducendo il numero di nodi al valore indicato.\n"
		"Comando necessario nel caso di polyline con più di 100 vertici (limite di SSAP)\n"
		"come nel caso di profili estratti da dtm.\n\n"
		"Crea di default un nuovo layer 'nomelayer_semplificato'"
	)
	QMessageBox.information(None, "Vettoriale → files SSAP (aiuto)", msg)

def _trim_info():
	"""UI slot: show a short help for back analysis """
	msg = (
		"Taglia tutte le polyline con estremi esterni ai limiti Xmin e Xmax della superficie topografica.\n"
		"Comando utile nel caso di editing con inserimento di nuovi strati:\n"
		"è infatti sufficiente estendere la polyline oltre i limiti della superficie topografica\n"
        "senza curarsi di posizionare esattamente i nodi esterni\n\n"
		"Crea di default un nuovo layer 'nomelayer_trim'"
        
	)
	QMessageBox.information(None, "Vettoriale → files SSAP (aiuto)", msg)
