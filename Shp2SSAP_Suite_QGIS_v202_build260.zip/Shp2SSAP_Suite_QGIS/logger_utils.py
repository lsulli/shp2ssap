# -*- coding: utf-8 -*-
"""Minimal call logger for Shp2SSAP Suite QGIS plugin.

Writes a log file in the user's Downloads folder:
    ~/Downloads/qgis_plugin_log.txt

Keeps implementation small and resilient across QGIS/Qt signal signatures.
"""

from __future__ import annotations

import inspect
import logging
import os
from functools import wraps
from types import FunctionType
from typing import Any, Callable, Dict

_LOG_DIR = os.path.join(os.path.expanduser("~"), "Downloads")
try:
    os.makedirs(_LOG_DIR, exist_ok=True)
except Exception:
    _LOG_DIR = None

_LOG_FILE = os.path.join(_LOG_DIR, "qgis_plugin_log.txt") if _LOG_DIR else None

_logger = logging.getLogger("Shp2SSAPSuite_calls")
if not _logger.handlers and _LOG_FILE:
    _logger.setLevel(logging.INFO)
    _fh = logging.FileHandler(_LOG_FILE, encoding="utf-8")
    _fh.setFormatter(logging.Formatter("%(asctime)s - %(message)s"))
    _logger.addHandler(_fh)
    _logger.propagate = False


def log_call(func: Callable[..., Any]) -> Callable[..., Any]:
    """Decorator that logs calls and tolerates extra Qt signal args.

    If the wrapped callable fails due to a mismatched signature (common with QAction
    signals passing a 'checked' bool), it retries dropping extra args.
    """
    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            _logger.info(f"{func.__module__}.{func.__qualname__}")
        except Exception:
            pass

        # Normal path: forward all args/kwargs
        try:
            return func(*args, **kwargs)
        except TypeError:
            # Retry: drop extra positional args (keep 'self' if present)
            if args:
                try:
                    return func(args[0])
                except Exception:
                    raise
            raise

    return wrapper


def auto_log_methods(cls: type) -> type:
    """Class decorator: wraps all methods with log_call."""
    for name, method in inspect.getmembers(cls, inspect.isfunction):
        setattr(cls, name, log_call(method))
    return cls


def auto_log_module_functions(module_globals: Dict[str, Any]) -> None:
    """Wrap module-level functions in-place.

    Wraps public functions (no leading underscore).
    """
    for name, obj in list(module_globals.items()):
        if name.startswith("_"):
            continue
        if isinstance(obj, FunctionType):
            module_globals[name] = log_call(obj)
