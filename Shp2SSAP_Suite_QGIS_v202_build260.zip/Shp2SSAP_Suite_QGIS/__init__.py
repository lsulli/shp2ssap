def classFactory(iface):
    from .plugin import Shp2SSAPSuitePlugin
    return Shp2SSAPSuitePlugin(iface)
