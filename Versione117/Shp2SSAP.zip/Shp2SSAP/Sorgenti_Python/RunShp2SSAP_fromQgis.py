## Open in Python Console from QGis and run to start Shp2SSAP.exe
import os
import subprocess
os.chdir("C:\Shp2SSAP")
subprocess.call("C:\Shp2SSAP\Shp2SSAp.exe")