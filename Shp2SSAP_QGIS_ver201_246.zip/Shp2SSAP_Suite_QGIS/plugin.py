import os
from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

from .dialog import Shp2SSAPSuiteDialog


class Shp2SSAPSuitePlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dlg = None
        self.plugin_dir = os.path.dirname(__file__)

    def tr(self, msg: str) -> str:
        return QCoreApplication.translate("Shp2SSAPSuite", msg)

    def initGui(self):
        self.action = QAction(QIcon(os.path.join(self.plugin_dir, "xy2Shp_forSSAP.ico")), self.tr("Shp2SSAP Suite"), self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.action.setToolTip(self.tr("Shp2SSAP Suite (XY↔SHP↔SSAP)"))
        self.action.setStatusTip(self.tr("Converti XY↔Shapefile↔SSAP"))
        self.iface.addPluginToMenu(self.tr("&Shp2SSAP Suite"), self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu(self.tr("&Shp2SSAP Suite"), self.action)
            self.iface.removeToolBarIcon(self.action)

    def run(self):
        if self.dlg is None:
            self.dlg = Shp2SSAPSuiteDialog(self.iface)
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()
