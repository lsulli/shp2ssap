#!/usr/bin/env pythonw
# -*- coding: utf-8 -*-

"""
Suite unificata: xy2shp_forSSAP_101_029 + Shp2_SSAP_v200 in una sola GUI (Tkinter Notebook)

- Tab 1: XY -> Shapefile SSAP (da script xy2shp_forSSAP_101_029)
- Tab 2: Shapefile -> files SSAP (da script Shp2_SSAP_v200)

Compatibile: Windows, Python 3.13+, pyshp (shapefile.py)
pyperclip: opzionale (abilita input da appunti)

Autore originale: Lorenzo Sulli - lorenzo.sulli@gmail.com
Refactoring/integrazione: ChatGPT 5.2

LICENZA: http://www.gnu.org/licenses/gpl.html

Le procedure fondamentali utilizzano il modulo shapefile.py (credit - https://github.com/GeospatialPython/pyshp)

Per il software SSAP2010 vedi termini di licenza riportati in www.SSAP.eu

Per la guida all'uso dello script vedi https://github.com/lsulli/shp2ssap

"""

from __future__ import annotations

import datetime as _dt
import linecache
import logging
import math
import os
import re
import shutil
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass
from math import atan, degrees
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

import tkinter as tk
from tkinter import ttk, messagebox, filedialog

# =========================
# Dipendenze
# =========================
try:
    import shapefile  # pyshp
except ImportError as e:
    messagebox.showerror("Errore", f"Impossibile importare 'shapefile' (pyshp).\nDettaglio: {e}")
    raise

try:
    import pyperclip  # opzionale
except Exception:
    pyperclip = None


# =========================
# Logging (unificato)
# =========================
LOG_PATH = Path.cwd() / "Shp2SSAP_Suite.log"
logging.basicConfig(
    filename=str(LOG_PATH),
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logging.info("Avvio Shp2SSAP Suite")


# =========================
# ---------------------------
#  PARTE A: Shp2SSAP (script A)
# ---------------------------
# =========================

# Etichette / messaggi (fallback se manca s2s_lbl)
class _LblFallback:
    versione = "2.0.1 build 217"
    root_title = "Shp2SSAP Suite"
    msg_title = "Shp2SSAP"
    msg_title_error = "Errore"
    msg_title_check = "Verifica shapefile"

    msg_error01 = "ERRORE 01: impossibile leggere shapefile.\n"
    msg_error02 = "ERRORE 02: mancano campi obbligatori.\nCampi mancanti: "
    msg_error03 = "ERRORE 03: valori non ammessi nel campo SSAP: "
    msg_error04 = "ERRORE 04: shapefile non è di tipo Polyline.\n"
    msg_error11 = "\nERRORE 11: ordine verticale strati (top→bottom) non coerente.\n"

    msg_err_end1 = "\nCorreggi gli errori e riprova."
    msg_err_end2 = "\nSeleziona un percorso di output valido."
    header_msg_error = "Errore non previsto.\n"

    xy2Shp_forSSAP_str = ".\\xy2Shp_forSSAP\\xy2Shp_forSSAP.exe"


try:
    import s2s_lbl  # type: ignore
    LBL = s2s_lbl
except Exception:
    LBL = _LblFallback()


def format_float_str(v: float) -> str:
    return f"{float(v):.2f}"


def read_default_txt_A() -> dict:
    """Parser 'storico' usato da Shp2SSAP (script A)."""
    out = {
        "def_shp_dir": "",
        "def_ssap_dir": "",
        "max_char_msg_err": 750,
        "trim_tolerance_factor": 20,
    }
    p = Path("default.txt")
    if not p.exists():
        return out

    try:
        def_shp = (Path.cwd() / linecache.getline(str(p), 2).strip()).as_posix()
        def_ssap = (Path.cwd() / linecache.getline(str(p), 4).strip()).as_posix()
        out["def_shp_dir"] = def_shp if Path(def_shp).exists() else ""
        out["def_ssap_dir"] = def_ssap if Path(def_ssap).exists() else ""

        max_char = linecache.getline(str(p), 6).strip()
        if max_char.isdigit():
            out["max_char_msg_err"] = int(max_char)

        ttf = linecache.getline(str(p), 8).strip()
        if ttf.isdigit():
            out["trim_tolerance_factor"] = max(20, int(ttf))
    finally:
        linecache.clearcache()

    return out


DEFAULTS_A = read_default_txt_A()


@dataclass(frozen=True)
class FieldIndex:
    ssap_id: int
    ssap: int
    phi: int
    cu: int
    c: int
    gamma: int
    gammasat: int
    exclude: int
    dr_undr: int
    val1: Optional[int] = None
    sigci: Optional[int] = None
    gsi: Optional[int] = None
    mi: Optional[int] = None
    d: Optional[int] = None


@dataclass(frozen=True)
class Feature:
    idx: int
    ssap: str
    ssap_id: int
    exclude: bool
    record: Sequence
    points: Sequence[Tuple[float, float]]


@dataclass(frozen=True)
class TopoLimits:
    x_min: float
    x_max: float
    tol: float


class SSAPError(Exception):
    pass


def _norm(s) -> str:
    return str(s).strip().lower()


def get_field_index(sf: shapefile.Reader) -> Tuple[FieldIndex, dict]:
    fields = sf.fields
    name_to_idx: dict[str, int] = {}
    for i, f in enumerate(fields):
        name = str(f[0]).upper()
        if name == "DELETIONFLAG":
            continue
        name_to_idx[name] = i - 1  # -1 per compensare DeletionFlag

    required = ["SSAP_ID", "SSAP", "PHI", "CU", "C", "GAMMA", "GAMMASAT", "EXCLUDE", "DR_UNDR"]
    missing = [x for x in required if x not in name_to_idx]
    if missing:
        raise SSAPError(LBL.msg_error02 + str(missing))

    flags = {
        "has_svr": "VAL1" in name_to_idx,
        "has_rock": all(k in name_to_idx for k in ["SIGCI", "GSI", "MI", "D"]),
    }

    fi = FieldIndex(
        ssap_id=name_to_idx["SSAP_ID"],
        ssap=name_to_idx["SSAP"],
        phi=name_to_idx["PHI"],
        cu=name_to_idx["CU"],
        c=name_to_idx["C"],
        gamma=name_to_idx["GAMMA"],
        gammasat=name_to_idx["GAMMASAT"],
        exclude=name_to_idx["EXCLUDE"],
        dr_undr=name_to_idx["DR_UNDR"],
        val1=name_to_idx.get("VAL1"),
        sigci=name_to_idx.get("SIGCI"),
        gsi=name_to_idx.get("GSI"),
        mi=name_to_idx.get("MI"),
        d=name_to_idx.get("D"),
    )
    return fi, flags


def iter_features(sf: shapefile.Reader, fi: FieldIndex) -> list[Feature]:
    feats: list[Feature] = []
    try:
        n = int(sf.numRecords)
    except Exception:
        n = len(sf.shapeRecords())

    for i in range(n):
        sr = sf.shapeRecord(i)
        rec = sr.record
        pts = sr.shape.points
        feats.append(
            Feature(
                idx=i,
                ssap=_norm(rec[fi.ssap]),
                ssap_id=rec[fi.ssap_id],
                exclude=(rec[fi.exclude] == 1),
                record=rec,
                points=pts,
            )
        )
    return feats


def check_shape_type(sf: shapefile.Reader) -> None:
    shapes = sf.shapes()
    if not shapes:
        raise SSAPError("Shapefile vuoto.")
    if shapes[0].shapeType != 3:
        raise SSAPError(LBL.msg_error04)


def check_field_ssap_values(features: Sequence[Feature]) -> None:
    allowed = {"dat", "fld", "svr", "sin"}
    bad = sorted({f.ssap for f in features if f.ssap not in allowed})
    if bad:
        raise SSAPError(LBL.msg_error03 + str(bad))


def check_layers_number(features: Sequence[Feature], ssap_type: str, max_num: int) -> None:
    n = sum(1 for f in features if (not f.exclude) and f.ssap == ssap_type)
    if n > max_num:
        raise SSAPError(f"\nERRORE 05: numero strati '{ssap_type}' = {n}, superiore a {max_num} (limite SSAP).\n")


def check_points_number(features: Sequence[Feature], simplify_enabled: bool) -> None:
    if simplify_enabled:
        return
    bad = [f for f in features if (not f.exclude) and len(f.points) > 100 and f.ssap in {"dat", "fld", "sin"}]
    if bad:
        msg = "\nERRORE 06: presenti strati con numero punti > 100 (limite SSAP) e semplificazione disattiva:\n"
        for f in bad:
            msg += f"- Strato '{f.ssap}' ID={f.ssap_id} punti={len(f.points)}\n"
        raise SSAPError(msg)


def check_id_zero(features: Sequence[Feature]) -> None:
    msg = ""
    for f in features:
        if f.exclude:
            continue
        if f.ssap != "fld" and f.ssap_id == 0:
            msg += f"\nERRORE 07: strato SSAP='{f.ssap}' con SSAP_ID=0 (ammesso solo per fld).\n"
        if f.ssap == "fld" and f.ssap_id != 0:
            msg += f"\nERRORE 07: strato fld deve avere SSAP_ID=0 (trovato {f.ssap_id}).\n"
    if msg:
        raise SSAPError(msg)


def check_all_negative_val(features: Sequence[Feature]) -> None:
    msg = ""
    for f in features:
        if f.exclude:
            continue
        for (x, y) in f.points:
            if x < 0 or y < 0:
                msg += f"- Strato '{f.ssap}' ID={f.ssap_id}: x={format_float_str(x)} y={format_float_str(y)}\n"
                break
    if msg:
        raise SSAPError("\nERRORE 08: presenti coordinate negative:\n" + msg)


def check_jutting_surface(features: Sequence[Feature]) -> None:
    topo = next((f for f in features if (not f.exclude) and f.ssap == "dat" and f.ssap_id == 1), None)
    if not topo or len(topo.points) < 2:
        return
    xs = [p[0] for p in topo.points]
    for i in range(len(xs) - 1):
        if xs[i] > xs[i + 1]:
            raise SSAPError("\nERRORE 09: la superficie topografica presenta una forma aggettante.\n")


def check_continuous_order(features: Sequence[Feature], ssap_type: str) -> None:
    ids = sorted([f.ssap_id for f in features if (not f.exclude) and f.ssap == ssap_type])
    if not ids:
        return
    start = 0 if ids[0] == 0 else 1
    expected = list(range(start, start + len(ids)))
    if ids != expected:
        raise SSAPError(
            f"\nERRORE 10: sequenza SSAP_ID non continua per '{ssap_type}'.\n"
            f"ID trovati (ordinati): {ids}\nID attesi: {expected}\n"
        )


def check_top_bottom_order(features: Sequence[Feature]) -> None:
    dats = sorted([f for f in features if (not f.exclude) and f.ssap == "dat"], key=lambda x: x.ssap_id)
    if len(dats) < 2:
        return

    mins = []
    maxs = []
    cents = []
    for f in dats:
        ys = [round(p[1], 2) for p in f.points]
        mins.append(min(ys))
        maxs.append(max(ys))
        cents.append(round(sum(ys) / len(ys), 2))

    def is_desc(v: list[float]) -> bool:
        return v == sorted(v, reverse=True)

    if not (is_desc(mins) or is_desc(maxs) or is_desc(cents)):
        raise SSAPError(LBL.msg_error11)


def run_precheck(sf: shapefile.Reader, features: Sequence[Feature], simplify: bool, check_topbottom: bool) -> dict:
    check_shape_type(sf)
    check_field_ssap_values(features)
    check_layers_number(features, "dat", 20)
    check_layers_number(features, "svr", 10)
    check_layers_number(features, "fld", 1)
    check_layers_number(features, "sin", 1)
    check_points_number(features, simplify_enabled=simplify)
    check_id_zero(features)
    check_all_negative_val(features)
    check_jutting_surface(features)
    check_continuous_order(features, "dat")
    check_continuous_order(features, "svr")
    if check_topbottom:
        check_top_bottom_order(features)

    return {
        "dat": sum(1 for f in features if (not f.exclude) and f.ssap == "dat"),
        "fld": sum(1 for f in features if (not f.exclude) and f.ssap == "fld"),
        "svr": sum(1 for f in features if (not f.exclude) and f.ssap == "svr"),
        "sin": sum(1 for f in features if (not f.exclude) and f.ssap == "sin"),
    }


def topo_limits(features: Sequence[Feature], trim_factor: int) -> TopoLimits:
    topo = next((f for f in features if (not f.exclude) and f.ssap == "dat" and f.ssap_id == 1), None)
    if not topo:
        return TopoLimits(0.0, 0.0, 0.0)
    x_min = round(topo.points[0][0], 2)
    x_max = round(topo.points[-1][0], 2)
    length = round(x_max - x_min, 2)
    tol = round(length / max(20, trim_factor), 2)
    return TopoLimits(x_min, x_max, tol)


def xy_ref(points: Sequence[Tuple[float, float]], topo: TopoLimits) -> Tuple[float, float, float, float, float, float, float, float]:
    if len(points) < 2:
        return (0, 0, 0, 0, 0, 0, 0, 0)

    left_idx = 1
    for i, (x, _y) in enumerate(points):
        if x > (topo.x_min + topo.tol):
            left_idx = max(1, i)
            break

    right_idx = len(points) - 1
    for i, (x, _y) in enumerate(points):
        if x > (topo.x_max - topo.tol):
            right_idx = max(1, i)
            break

    x1sx, y1sx = points[left_idx - 1]
    x2sx, y2sx = points[left_idx]
    x1dx, y1dx = points[right_idx - 1]
    x2dx, y2dx = points[right_idx]
    return (round(x1sx, 2), round(y1sx, 2), round(x2sx, 2), round(y2sx, 2),
            round(x1dx, 2), round(y1dx, 2), round(x2dx, 2), round(y2dx, 2))


def y_on_line(x1: float, y1: float, x2: float, y2: float, x: float) -> float:
    if x2 == x1:
        return y1
    return (((x - x1) / (x2 - x1)) * (y2 - y1)) + y1


def apply_trimming(
    x: float, y: float,
    x_first: float, x_last: float,
    topo: TopoLimits,
    refs: Tuple[float, float, float, float, float, float, float, float],
    layer_id: int,
) -> Tuple[float, float]:
    x1sx, y1sx, x2sx, y2sx, x1dx, y1dx, x2dx, y2dx = refs
    if x < (topo.x_min + topo.tol) and x == x_first:
        new_x = topo.x_min
        new_y = y if (layer_id == 1 or x_first == topo.x_min) else y_on_line(x1sx, y1sx, x2sx, y2sx, topo.x_min)
        return new_x, new_y
    if x > (topo.x_max - topo.tol) and x == x_last:
        new_x = topo.x_max
        new_y = y if (layer_id == 1 or x_last == topo.x_max) else y_on_line(x1dx, y1dx, x2dx, y2dx, topo.x_max)
        return new_x, new_y
    return x, y


def simplify_step(n_points: int, simplify_enabled: bool) -> int:
    if not simplify_enabled or n_points <= 100:
        return 1
    return max(1, math.ceil(n_points / 99))


def safe_rmtree(path: Path, retries: int = 8, delay: float = 0.2) -> None:
    for _ in range(retries):
        try:
            if path.exists():
                shutil.rmtree(path, ignore_errors=False)
            return
        except (PermissionError, OSError):
            time.sleep(delay)
    logging.warning("Impossibile cancellare temp dir (lock Windows): %s", path)


def write_ssap_files(
    shp_path: Path,
    out_base: Path,
    simplify: bool,
    trimming: bool,
    check_topbottom: bool,
) -> list[Path]:
    created: list[Path] = []
    trim_factor = int(DEFAULTS_A["trim_tolerance_factor"])

    tmp_root = Path(tempfile.gettempdir())
    td_path = tmp_root / f"shp2ssap_{uuid.uuid4().hex}"
    td_path.mkdir(parents=True, exist_ok=True)

    sf = None
    try:
        base = shp_path.with_suffix("")

        # Copia trio shapefile
        for ext in (".shp", ".dbf", ".shx"):
            src = base.with_suffix(ext)
            if not src.exists():
                raise SSAPError(f"Manca il file {src.name} (necessari .shp .dbf .shx).")
            shutil.copy2(src, td_path / src.name)

        tmp_shp = td_path / shp_path.name

        sf = shapefile.Reader(str(tmp_shp))
        fi, flags = get_field_index(sf)
        features = iter_features(sf, fi)

        counts = run_precheck(sf, features, simplify=simplify, check_topbottom=check_topbottom)

        dat_layers = sorted([f for f in features if (not f.exclude) and f.ssap == "dat"], key=lambda x: x.ssap_id)
        fld_layer = next((f for f in features if (not f.exclude) and f.ssap == "fld"), None)
        svr_layers = sorted([f for f in features if (not f.exclude) and f.ssap == "svr"], key=lambda x: x.ssap_id)
        sin_layers = [f for f in features if (not f.exclude) and f.ssap == "sin"]

        topo = topo_limits(features, trim_factor)

        t = _dt.datetime.now()
        header_date = f"File creato in data: {t.strftime('%A, %d %B %Y %H:%M')}"

        p_dat = out_base.with_suffix(".dat")
        p_geo = out_base.with_suffix(".geo")
        p_mod = out_base.with_suffix(".mod")
        p_fld = out_base.with_suffix(".fld")
        p_svr = out_base.with_suffix(".svr")
        p_sin = out_base.with_suffix(".sin")

        try:
            with open(p_dat, "w", encoding="utf-8", newline="\n") as f_dat, \
                 open(p_geo, "w", encoding="utf-8", newline="\n") as f_geo, \
                 open(p_mod, "w", encoding="utf-8", newline="\n") as f_mod:

                created.extend([p_dat, p_geo, p_mod])

                f_dat.write("|" + header_date + "\n")
                f_dat.write("|" + f"File .dat per SSAP2010 generato da Shp2SSAP, versione {LBL.versione}\n")
                f_dat.write("|" + f"Shapefile di input: '{shp_path}'\n")

                # DAT + GEO
                for lay in dat_layers:
                    pts = list(lay.points)
                    if not pts:
                        continue

                    step = simplify_step(len(pts), simplify)
                    refs = xy_ref(pts, topo) if (trimming and topo.tol > 0) else (0,0,0,0,0,0,0,0)

                    rec = lay.record
                    dr = _norm(rec[fi.dr_undr])

                    is_rock = bool(flags.get("has_rock")) and fi.sigci is not None and float(rec[fi.sigci] or 0) > 0

                    if not is_rock:
                        if dr != "u":
                            f_geo.write("\t" + str(rec[fi.phi]))
                            f_geo.write("\t" + str(rec[fi.c]))
                            f_geo.write("\t0")
                        else:
                            cu = float(rec[fi.cu] or 0)
                            if cu == 0:
                                raise SSAPError(
                                    f"- Il valore di CU dello strato {lay.ssap_id} è zero: verifica non drenata non applicabile.\n"
                                )
                            f_geo.write("\t0\t0\t" + str(rec[fi.cu]))

                        f_geo.write("\t" + str(rec[fi.gamma]))
                        f_geo.write("\t" + str(rec[fi.gammasat]) + "\n")
                    else:
                        f_geo.write("\t0\t0\t0")
                        f_geo.write("\t" + str(rec[fi.gamma]))
                        f_geo.write("\t" + str(rec[fi.gammasat]))
                        f_geo.write("\t" + str(rec[fi.sigci]))
                        f_geo.write("\t" + str(rec[fi.gsi]))
                        f_geo.write("\t" + str(rec[fi.mi]))
                        f_geo.write("\t" + str(rec[fi.d]) + "\n")

                    f_dat.write(f"##{lay.ssap_id}-------------------------- Numero punti: ~{int(len(pts)/step)}\n")

                    x_first = pts[0][0]
                    x_last = max(p[0] for p in pts)

                    for (x, y) in pts[::step]:
                        if trimming and topo.tol > 0:
                            x2, y2 = apply_trimming(x, y, x_first, x_last, topo, refs, lay.ssap_id)
                        else:
                            x2, y2 = x, y
                        f_dat.write("\t" + format_float_str(x2) + "\t\t" + format_float_str(y2) + "\n")

                # FLD
                has_fld = False
                if fld_layer is not None:
                    has_fld = True
                    with open(p_fld, "w", encoding="utf-8", newline="\n") as f_fld:
                        created.append(p_fld)
                        pts = list(fld_layer.points)
                        step = simplify_step(len(pts), simplify)
                        refs = xy_ref(pts, topo) if (trimming and topo.tol > 0) else (0,0,0,0,0,0,0,0)

                        x_first = pts[0][0] if pts else 0
                        x_last = max((p[0] for p in pts), default=0)

                        for (x, y) in pts[::step]:
                            if trimming and topo.tol > 0:
                                x2, y2 = apply_trimming(x, y, x_first, x_last, topo, refs, fld_layer.ssap_id)
                            else:
                                x2, y2 = x, y
                            f_fld.write("\t" + format_float_str(x2) + "\t\t" + format_float_str(y2) + "\n")

                # SVR
                has_svr = False
                if svr_layers and flags.get("has_svr") and fi.val1 is not None:
                    has_svr = True
                    with open(p_svr, "w", encoding="utf-8", newline="\n") as f_svr:
                        created.append(p_svr)
                        for lay in svr_layers:
                            pts = list(lay.points)
                            if len(pts) < 2:
                                continue
                            x_min = pts[0][0]
                            x_max = pts[-1][0]
                            val1 = lay.record[fi.val1]
                            f_svr.write(format_float_str(x_min) + "\t" +
                                        format_float_str(x_max) + "\t" +
                                        format_float_str(float(val1)) + "\n")

                # SIN
                if sin_layers:
                    with open(p_sin, "w", encoding="utf-8", newline="\n") as f_sin:
                        created.append(p_sin)
                        f_sin.write("# Shp2SSAP - versione: " + str(LBL.versione) + "\n")
                        f_sin.write("# file " + str(p_sin.name) + " creato da Shapefile di input: '" + str(shp_path) + "'\n")
                        for lay in sin_layers:
                            pts = list(lay.points)
                            step = simplify_step(len(pts), simplify)
                            for (x, y) in pts[::step]:
                                f_sin.write("\t" + format_float_str(x) + "\t\t" + format_float_str(y) + "\n")

                # MOD
                dat_count = counts["dat"]
                f_mod.write(f"{dat_count}    {1 if has_fld else 0}    {1 if has_svr else 0}    0    0    0\n")
                f_mod.write(p_dat.name + "\n")
                if has_fld:
                    f_mod.write(p_fld.name + "\n")
                f_mod.write(p_geo.name + "\n")
                if has_svr:
                    f_mod.write(p_svr.name + "\n")

            return created

        except Exception:
            for p in created:
                try:
                    if p.exists():
                        p.unlink()
                except Exception:
                    pass
            raise

    finally:
        try:
            if sf is not None:
                sf.close()
        except Exception:
            pass
        safe_rmtree(td_path)


class Shp2SSAPFrame(ttk.Frame):
    """Tab: Shapefile -> SSAP files (script A)."""

    def __init__(self, master: tk.Misc) -> None:
        super().__init__(master, padding="12 12 12 12")

        self.var_shp = tk.StringVar()
        self.var_out = tk.StringVar()

        self.opt_check_topbottom = tk.IntVar(value=1)
        self.opt_trimming = tk.IntVar(value=1)
        self.opt_simplify = tk.IntVar(value=1)

        self._build_ui()
        self._bind_state()
        self._update_buttons()

    def _build_ui(self) -> None:
        self.columnconfigure(1, weight=1)

        self.btn_input_shp = ttk.Button(self, text="Input Shapefile", command=self.load_shapefile)
        self.btn_input_shp.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=4, padx=8)

        self.btn_output_ssapfile = ttk.Button(self, text="Output SSAP files", command=self.save_files_ssap)
        self.btn_output_ssapfile.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=4, padx=8)

        ttk.Entry(self, width=75, textvariable=self.var_shp).grid(row=0, column=1, sticky=(tk.E, tk.W))
        ttk.Entry(self, width=75, textvariable=self.var_out).grid(row=1, column=1, sticky=(tk.E, tk.W))

        ttk.Separator(self, orient=tk.HORIZONTAL).grid(column=0, row=2, sticky=(tk.E, tk.W), pady=8, columnspan=2)

        ttk.Label(self, text="Opzioni controllo e creazione strati", borderwidth=5, relief=tk.GROOVE).grid(
            column=0, row=3, pady=6, ipadx=10, ipady=3, sticky=(tk.E, tk.W), columnspan=2
        )

        ttk.Checkbutton(
            self, text="Verifica ordinamento verticale strati",
            variable=self.opt_check_topbottom, onvalue=1, offvalue=0
        ).grid(row=4, column=0, sticky=tk.W, columnspan=2)

        ttk.Checkbutton(
            self, text="Regola gli strati alla superficie topografica",
            variable=self.opt_trimming, onvalue=1, offvalue=0
        ).grid(row=5, column=0, sticky=tk.W, columnspan=2)

        ttk.Checkbutton(
            self, text="Semplifica polyline se > 100 punti",
            variable=self.opt_simplify, onvalue=1, offvalue=0
        ).grid(row=6, column=0, sticky=tk.W, columnspan=2)

        ttk.Separator(self, orient=tk.HORIZONTAL).grid(column=0, row=7, sticky=(tk.E, tk.W), pady=10, columnspan=2)

        self.btn_check = ttk.Button(self, text=" Verifica preliminare Shape ", command=self.do_check, state="disabled")
        self.btn_conv = ttk.Button(self, text=" Converti ", command=self.do_convert, state="disabled")
        self.btn_check.grid(row=8, column=0, sticky=tk.W, pady=4)
        self.btn_conv.grid(row=8, column=0, sticky=tk.E, pady=4, padx=(160,0))

    def _bind_state(self) -> None:
        self.var_shp.trace_add("write", lambda *_: self._update_buttons())
        self.var_out.trace_add("write", lambda *_: self._update_buttons())

    def _update_buttons(self) -> None:
        shp_ok = bool(self.var_shp.get()) and Path(self.var_shp.get()).exists()
        out_ok = bool(self.var_out.get()) and Path(self.var_out.get()).parent.exists()
        self.btn_output_ssapfile.configure(state="normal" if shp_ok else "disabled")
        self.btn_check.configure(state="normal" if shp_ok else "disabled")
        self.btn_conv.configure(state="normal" if (shp_ok and out_ok) else "disabled")

    def load_shapefile(self) -> None:
        try:
            initial = DEFAULTS_A.get("def_shp_dir") or ""
            shp_name = filedialog.askopenfilename(
                filetypes=(("Shapefile", "*.shp"), ("All files", "*.*")),
                initialdir=initial or None,
            )
            if shp_name:
                self.var_shp.set(shp_name)
        except Exception as e:
            logging.exception("Errore load_shapefile")
            messagebox.showerror(LBL.msg_title_error, str(e))

    def save_files_ssap(self) -> None:
        try:
            initial = DEFAULTS_A.get("def_ssap_dir") or ""
            name = filedialog.asksaveasfilename(
                filetypes=(("SSAP FILES", "*.mod*"), ("All files", "*.*")),
                initialdir=initial or None,
            )
            if name:
                self.var_out.set(str(Path(name).with_suffix("")))
        except Exception as e:
            logging.exception("Errore save_files_ssap")
            messagebox.showerror(LBL.msg_title_error, str(e))

    def do_check(self) -> None:
        shp = Path(self.var_shp.get())
        if not shp.exists():
            return
        sf = None
        try:
            sf = shapefile.Reader(str(shp))
            fi, _flags = get_field_index(sf)
            feats = iter_features(sf, fi)
            run_precheck(
                sf, feats,
                simplify=bool(self.opt_simplify.get()),
                check_topbottom=bool(self.opt_check_topbottom.get()),
            )
            messagebox.showinfo(LBL.msg_title_check, f"Shapefile OK:\n{shp}")
        except SSAPError as e:
            msg = str(e)
            maxc = int(DEFAULTS_A.get("max_char_msg_err", 750))
            if len(msg) > maxc:
                msg = msg[: maxc] + "\n...\n"
            messagebox.showerror(LBL.msg_title_error, f"##### Shapefile: '{shp}'\n{msg}\n{LBL.msg_err_end1}")
        except Exception as e:
            logging.exception("Errore do_check")
            messagebox.showerror(LBL.msg_title_error, f"{LBL.header_msg_error}\n{e}")
        finally:
            try:
                if sf is not None:
                    sf.close()
            except Exception:
                pass

    def do_convert(self) -> None:
        shp = Path(self.var_shp.get())
        out = Path(self.var_out.get())
        if not shp.exists():
            return
        if not out.parent.exists():
            messagebox.showerror(LBL.msg_title_error, LBL.msg_err_end2)
            return

        try:
            created = write_ssap_files(
                shp_path=shp,
                out_base=out,
                simplify=bool(self.opt_simplify.get()),
                trimming=bool(self.opt_trimming.get()),
                check_topbottom=bool(self.opt_check_topbottom.get()),
            )
            messagebox.showinfo(LBL.msg_title, "Procedura conclusa.\nCreati:\n" + "\n".join(str(p) for p in created))
        except SSAPError as e:
            msg = str(e)
            maxc = int(DEFAULTS_A.get("max_char_msg_err", 750))
            if len(msg) > maxc:
                msg = msg[: maxc] + "\n...\n"
            messagebox.showerror(LBL.msg_title_error, f"##### Shapefile: '{shp}'\n{msg}\n{LBL.msg_err_end1}")
        except Exception as e:
            logging.exception("Errore do_convert")
            messagebox.showerror(LBL.msg_title_error, f"{LBL.header_msg_error}\n{e}\n\nLog: {LOG_PATH}")


# =========================
# ---------------------------
#  PARTE B: xy2Shp_forSSAP (script B)
# ---------------------------
# =========================

APP_NAME_B = "xy2Shp_forSSAP"
VERSION_B = "1.0.1 build 30"
MSG_TITLE_B = APP_NAME_B
MSG_TITLE_ERROR_B = "Gestione Errori"
MSG_CLIPBOARD_B = "Sorgente dati: appunti"
DEFAULT_FILE_B = "default.txt"

_SPLIT_RE = re.compile(r"[;\t:|]+|(?:(?<=\d)\s+(?=-?\d))")


@dataclass(frozen=True)
class DefaultsB:
    input_shapefile_dir: str = ""
    output_ssap_dir: str = ""
    input_xy_dir: str = ""
    output_shp_dir: str = ""
    max_error_chars: int = 1100
    tolerance_factor: float = 0.0
    phi: float = 0.0
    c: float = 0.0
    cu: float = 0.0
    gamma: float = 0.0
    gammasat: float = 0.0
    falda_deep: float = 0.0
    bedrock_deep: float = 5.0
    phi_br: float = 50.0
    c_br: float = 500.0


@dataclass(frozen=True)
class LayerValues:
    phi: float = 0.0
    c: float = 0.0
    cu: float = 0.0
    gamma: float = 0.0
    gammasat: float = 0.0


@dataclass(frozen=True)
class ConvertOptions:
    layer_values: LayerValues
    use_pendenza_media: bool
    falda_enabled: bool
    falda_depth: float
    bedrock_enabled: bool
    bedrock_depth: float
    phi_br: float
    c_br: float


def _to_float(s: str, fallback: float) -> float:
    try:
        s = (s or "").strip().replace(",", ".")
        return float(s) if s else fallback
    except Exception:
        return fallback


def _to_int(s: str, fallback: int) -> int:
    try:
        s = (s or "").strip()
        return int(float(s)) if s else fallback
    except Exception:
        return fallback


def load_defaults_B(default_file: str = DEFAULT_FILE_B) -> DefaultsB:
    p = Path(default_file)
    if not p.exists():
        logging.info("default.txt non trovato (B): uso DefaultsB() built-in")
        return DefaultsB()

    raw_lines = p.read_text(encoding="utf-8", errors="replace").splitlines()

    values: List[str] = []
    for line in raw_lines:
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        values.append(s)

    if len(values) < 5:
        logging.warning("default.txt presente ma incompleto (B): uso DefaultsB() built-in")
        return DefaultsB()

    def abs_dir(rel_or_abs: str) -> str:
        s = (rel_or_abs or "").strip()
        if not s:
            return ""
        if s.startswith("\\") or s.startswith("/"):
            return str(Path(os.getcwd()) / s.lstrip("\\/"))
        return str(Path(s))

    input_shp_dir = abs_dir(values[0]) if len(values) > 0 else ""
    output_ssap_dir = abs_dir(values[1]) if len(values) > 1 else ""
    max_err = _to_int(values[2], 1100) if len(values) > 2 else 1100
    tol_factor = _to_float(values[3], 0.0) if len(values) > 3 else 0.0
    input_xy_dir = abs_dir(values[4]) if len(values) > 4 else ""

    phi = _to_float(values[5], 0.0) if len(values) > 5 else 0.0
    c = _to_float(values[6], 0.0) if len(values) > 6 else 0.0
    cu = _to_float(values[7], 0.0) if len(values) > 7 else 0.0
    gamma = _to_float(values[8], 0.0) if len(values) > 8 else 0.0
    gammasat = _to_float(values[9], 0.0) if len(values) > 9 else 0.0
    falda = _to_float(values[10], 0.0) if len(values) > 10 else 0.0
    bedrock = _to_float(values[11], 5.0) if len(values) > 11 else 5.0
    phi_br = _to_float(values[12], 50.0) if len(values) > 12 else 50.0
    c_br = _to_float(values[13], 500.0) if len(values) > 13 else 500.0

    return DefaultsB(
        input_shapefile_dir=input_shp_dir,
        output_ssap_dir=output_ssap_dir,
        input_xy_dir=input_xy_dir,
        output_shp_dir=output_ssap_dir,
        max_error_chars=max_err,
        tolerance_factor=tol_factor,
        phi=phi, c=c, cu=cu, gamma=gamma, gammasat=gammasat,
        falda_deep=falda, bedrock_deep=bedrock,
        phi_br=phi_br, c_br=c_br,
    )


def parse_xy_points(text: str) -> List[List[float]]:
    points: List[List[float]] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        line = line.replace(",", ".")
        parts = [p for p in _SPLIT_RE.split(line) if p and p.strip()]
        if len(parts) != 2:
            continue
        try:
            x = float(parts[0])
            y = float(parts[1])
        except ValueError:
            continue
        points.append([x, y])
    return points


def compute_pendenza_media(points: List[List[float]]) -> Optional[float]:
    if len(points) < 2:
        return None
    try:
        dy = abs(points[-1][1] - points[0][1])
        dx = abs(points[-1][0] - points[0][0])
        if dx == 0:
            return None
        return round(degrees(atan(dy / dx)), 1)
    except Exception:
        return None


def _ensure_shp_extension(path: str) -> str:
    p = path.strip()
    if not p.lower().endswith(".shp"):
        p += ".shp"
    return p


def _writer_compat(shapeout_shp: str) -> shapefile.Writer:
    try:
        w = shapefile.Writer(shapeout_shp, shapeType=shapefile.POLYLINE)
        w.autoBalance = True
        w._compat_mode = "2x"  # type: ignore[attr-defined]
        return w
    except TypeError:
        w = shapefile.Writer(shapefile.POLYLINE)
        w.autoBalance = 1
        w._compat_mode = "1x"  # type: ignore[attr-defined]
        return w


def _writer_close_compat(w: shapefile.Writer, shapeout_shp: str) -> None:
    mode = getattr(w, "_compat_mode", "2x")
    if mode == "1x":
        base = os.path.splitext(shapeout_shp)[0]
        w.save(base)
    else:
        w.close()


def write_ssap_shapefile(shapeout: str, points: List[List[float]], opts: ConvertOptions) -> None:
    shapeout = _ensure_shp_extension(shapeout)
    w = _writer_compat(shapeout)

    # campi tabella
    w.field("SSAP", "C", 3)
    w.field("SSAP_ID", "N", 2, 0)
    w.field("DR_UNDR", "C", 2)
    w.field("PHI", "N", 6, 2)
    w.field("C", "N", 6, 2)
    w.field("CU", "N", 6, 2)
    w.field("GAMMA", "N", 6, 2)
    w.field("GAMMASAT", "N", 6, 2)
    w.field("SIGCI", "N", 6, 2)
    w.field("GSI", "N", 6, 2)
    w.field("MI", "N", 6, 2)
    w.field("D", "N", 6, 2)
    w.field("VAL1", "N", 11, 2)
    w.field("EXCLUDE", "N", 1, 0)

    # feature dat
    w.line([points])
    lv = opts.layer_values
    w.record(
        SSAP="dat", SSAP_ID=1, DR_UNDR="D",
        PHI=lv.phi, C=lv.c, CU=lv.cu, GAMMA=lv.gamma, GAMMASAT=lv.gammasat,
        SIGCI=0, GSI=0, MI=0, D=0, VAL1=0, EXCLUDE=0,
    )

    # feature falda (fld)
    if opts.falda_enabled:
        blist = [[p[0], p[1] - float(opts.falda_depth)] for p in points]
        w.line([blist])
        w.record(
            SSAP="fld", SSAP_ID=0, DR_UNDR="0",
            PHI=0, C=0, CU=0, GAMMA=0, GAMMASAT=0,
            SIGCI=0, GSI=0, MI=0, D=0, VAL1=0, EXCLUDE=0,
        )

    # feature bedrock
    if opts.bedrock_enabled:
        blist = [[p[0], p[1] - float(opts.bedrock_depth)] for p in points]
        w.line([blist])
        w.record(
            SSAP="dat", SSAP_ID=2, DR_UNDR="0",
            PHI=float(opts.phi_br), C=float(opts.c_br), CU=0,
            GAMMA=22, GAMMASAT=22,
            SIGCI=0, GSI=0, MI=0, D=0, VAL1=0, EXCLUDE=0,
        )

    _writer_close_compat(w, shapeout)

    sf = shapefile.Reader(shapeout)
    if not sf.shapes() or sf.shapes()[0].shapeType != shapefile.POLYLINE or len(sf.shapeRecords()) == 0:
        raise ValueError("Shapefile creato ma non valido (non lineare o senza features).")


def read_input_text(source: str) -> str:
    if source == MSG_CLIPBOARD_B:
        if pyperclip is None:
            raise RuntimeError("pyperclip non è installato: input da appunti non disponibile.")
        return pyperclip.paste()
    p = Path(source)
    return p.read_text(encoding="utf-8", errors="replace")


class XY2ShpFrame(ttk.Frame):
    """Tab: XY -> Shapefile for SSAP."""

    def __init__(self, master: tk.Misc) -> None:
        super().__init__(master, padding="12 12 12 12")
        self.defaults = load_defaults_B(DEFAULT_FILE_B)

        self._build_ui()
        self._wire_traces()
        self._refresh_convert_button()
        self._refresh_backanalysis_controls()

    def _build_ui(self) -> None:
        self.columnconfigure(1, weight=1)

        ttk.Button(self, text="Input file di testo", command=self.on_load_textfile)\
            .grid(row=0, column=0, sticky=tk.W, pady=4, padx=8)

        self.btn_clip = ttk.Button(self, text="Input appunti", command=self.on_load_clipboard)
        self.btn_clip.grid(row=0, column=0, sticky=tk.E, pady=4, padx=8)

        if pyperclip is None:
            self.btn_clip.configure(state="disabled")

        self.var_input = tk.StringVar(self)
        self.entry_input = ttk.Entry(self, width=70, textvariable=self.var_input)
        self.entry_input.grid(row=0, column=1, sticky=(tk.E, tk.W))

        ttk.Button(self, text="Output Shapefile per SSAP", command=self.on_save_shapefile)\
            .grid(row=1, column=0, sticky=(tk.W, tk.E), pady=4, padx=8)

        self.var_output = tk.StringVar(self)
        self.entry_output = ttk.Entry(self, width=70, textvariable=self.var_output)
        self.entry_output.grid(row=1, column=1, sticky=(tk.E, tk.W))

        ttk.Separator(self, orient=tk.HORIZONTAL).grid(column=0, row=2, sticky=(tk.E, tk.W), pady=10, columnspan=2)

        label = ttk.Label(self, text="Assegna valori a strato", borderwidth=5, relief=tk.GROOVE)
        label.grid(column=0, row=3, pady=6, ipadx=5, ipady=3, sticky=(tk.W, tk.E), columnspan=2)

        width_cb = 30

        # PHI
        self.chk_phi = tk.IntVar(value=0)
        self.cb_phi = tk.Checkbutton(self, text="Angolo d'attrito", variable=self.chk_phi,
                                     onvalue=1, offvalue=0, height=1, width=width_cb, anchor=tk.W)
        self.cb_phi.grid(row=4, column=0, sticky=tk.W)
        self.var_phi = tk.DoubleVar(value=self.defaults.phi)
        self.entry_phi = ttk.Entry(self, width=6, textvariable=self.var_phi, state=tk.DISABLED)
        self.entry_phi.grid(row=4, column=0, sticky=tk.E)

        # C
        self.chk_c = tk.IntVar(value=0)
        self.cb_c = tk.Checkbutton(self, text="Coesione drenata (Kpa)", variable=self.chk_c,
                                   onvalue=1, offvalue=0, height=1, width=width_cb, anchor=tk.W)
        self.cb_c.grid(row=5, column=0, sticky=tk.W)
        self.var_c = tk.DoubleVar(value=self.defaults.c)
        self.entry_c = ttk.Entry(self, width=6, textvariable=self.var_c, state=tk.DISABLED)
        self.entry_c.grid(row=5, column=0, sticky=tk.E)

        # CU
        self.chk_cu = tk.IntVar(value=0)
        self.cb_cu = tk.Checkbutton(self, text="Coesione non drenata (Kpa)", variable=self.chk_cu,
                                    onvalue=1, offvalue=0, height=1, width=width_cb, anchor=tk.W)
        self.cb_cu.grid(row=6, column=0, sticky=tk.W)
        self.var_cu = tk.DoubleVar(value=self.defaults.cu)
        self.entry_cu = ttk.Entry(self, width=6, textvariable=self.var_cu, state=tk.DISABLED)
        self.entry_cu.grid(row=6, column=0, sticky=tk.E)

        # GAMMA
        self.chk_gamma = tk.IntVar(value=0)
        self.cb_gamma = tk.Checkbutton(self, text="Peso di volume naturale (KN/mc):", variable=self.chk_gamma,
                                       onvalue=1, offvalue=0, height=1, width=width_cb, anchor=tk.W)
        self.cb_gamma.grid(row=4, column=1, sticky=tk.W, padx=50)
        self.var_gamma = tk.DoubleVar(value=self.defaults.gamma)
        self.entry_gamma = ttk.Entry(self, width=6, textvariable=self.var_gamma, state=tk.DISABLED)
        self.entry_gamma.grid(row=4, column=1, sticky=tk.E)

        # GAMMASAT
        self.chk_gammasat = tk.IntVar(value=0)
        self.cb_gammasat = tk.Checkbutton(self, text="Peso di volume saturo (KN/mc):", variable=self.chk_gammasat,
                                          onvalue=1, offvalue=0, height=1, width=width_cb, anchor=tk.W)
        self.cb_gammasat.grid(row=5, column=1, sticky=tk.W, padx=50)
        self.var_gammasat = tk.DoubleVar(value=self.defaults.gammasat)
        self.entry_gammasat = ttk.Entry(self, width=6, textvariable=self.var_gammasat, state=tk.DISABLED)
        self.entry_gammasat.grid(row=5, column=1, sticky=tk.E)

        ttk.Separator(self, orient=tk.HORIZONTAL).grid(column=0, row=7, sticky=(tk.E, tk.W), pady=10, columnspan=2)

        # Falda
        self.chk_falda = tk.IntVar(value=0)
        self.cb_falda = tk.Checkbutton(
            self,
            text="Superficie di saturazione parallela alla topografia a profondità di metri:",
            variable=self.chk_falda, onvalue=1, offvalue=0, height=1, width=60, anchor=tk.W
        )
        self.cb_falda.grid(row=8, column=0, sticky=tk.W, columnspan=2)
        self.var_falda = tk.DoubleVar(value=self.defaults.falda_deep)
        self.entry_falda = ttk.Entry(self, width=6, textvariable=self.var_falda, state=tk.DISABLED)
        self.entry_falda.grid(row=8, column=1, sticky=tk.E)

        # Back analysis
        self.chk_pendenza = tk.IntVar(value=0)
        self.cb_pendenza = tk.Checkbutton(
            self,
            text="Angolo d'attrito = pendenza media pendio e coesione = 0 kpa (back analysis condizioni residue)",
            variable=self.chk_pendenza, onvalue=1, offvalue=0, height=1, width=80, anchor=tk.W
        )
        self.cb_pendenza.grid(row=9, column=0, sticky=tk.W, columnspan=2)

        # Bedrock
        self.chk_bedrock = tk.IntVar(value=0)
        self.cb_bedrock = tk.Checkbutton(
            self,
            text="Substrato con resistenza infinita parallelo alla topografia a profondità di metri:",
            variable=self.chk_bedrock, onvalue=1, offvalue=0, height=1, width=60, anchor=tk.W
        )
        self.cb_bedrock.grid(row=10, column=0, sticky=tk.W, columnspan=2)
        self.var_bedrock = tk.DoubleVar(value=self.defaults.bedrock_deep)
        self.entry_bedrock = ttk.Entry(self, width=6, textvariable=self.var_bedrock, state=tk.DISABLED)
        self.entry_bedrock.grid(row=10, column=1, sticky=tk.E)

        ttk.Separator(self, orient=tk.HORIZONTAL).grid(column=0, row=11, sticky=(tk.E, tk.W), pady=10, columnspan=2)

        self.btn_convert = ttk.Button(self, text="Converti", command=self.on_convert)
        self.btn_convert.grid(row=12, column=0, sticky=tk.W, pady=4)
        self.btn_convert.state(["disabled"])

        ttk.Button(self, text="Info", command=self._show_info).grid(row=12, column=1, sticky=tk.E, pady=4)

    def _show_info(self) -> None:
        clip = "OK" if pyperclip is not None else "NON disponibile (installa pyperclip)"
        messagebox.showinfo(
            MSG_TITLE_B,
            f"{APP_NAME_B} {VERSION_B}\n\n"
            f"Clipboard: {clip}\n"
            f"Log: {LOG_PATH}"
        )

    def _wire_traces(self) -> None:
        self.var_input.trace_add("write", lambda *_: self._refresh_convert_button())
        self.var_output.trace_add("write", lambda *_: self._refresh_convert_button())

        self.chk_phi.trace_add("write", lambda *_: self._toggle_entry(self.entry_phi, self.chk_phi.get()))
        self.chk_c.trace_add("write", lambda *_: self._toggle_entry(self.entry_c, self.chk_c.get()))
        self.chk_cu.trace_add("write", lambda *_: self._toggle_entry(self.entry_cu, self.chk_cu.get()))
        self.chk_gamma.trace_add("write", lambda *_: self._toggle_entry(self.entry_gamma, self.chk_gamma.get()))
        self.chk_gammasat.trace_add("write", lambda *_: self._toggle_entry(self.entry_gammasat, self.chk_gammasat.get()))
        self.chk_falda.trace_add("write", lambda *_: self._toggle_entry(self.entry_falda, self.chk_falda.get()))
        self.chk_bedrock.trace_add("write", lambda *_: self._toggle_entry(self.entry_bedrock, self.chk_bedrock.get()))

        self.chk_pendenza.trace_add("write", lambda *_: self._refresh_backanalysis_controls())
        self.chk_phi.trace_add("write", lambda *_: self._refresh_backanalysis_controls())
        self.chk_c.trace_add("write", lambda *_: self._refresh_backanalysis_controls())

    def _toggle_entry(self, entry: ttk.Entry, enabled: int) -> None:
        entry.configure(state=(tk.NORMAL if enabled else tk.DISABLED))

    def _refresh_backanalysis_controls(self) -> None:
        if self.chk_pendenza.get() == 1:
            self.chk_phi.set(0)
            self.chk_c.set(0)
            self.cb_phi.configure(state=tk.DISABLED)
            self.cb_c.configure(state=tk.DISABLED)
            self.entry_phi.configure(state=tk.DISABLED)
            self.entry_c.configure(state=tk.DISABLED)
        else:
            self.cb_phi.configure(state=tk.NORMAL)
            self.cb_c.configure(state=tk.NORMAL)
            self._toggle_entry(self.entry_phi, self.chk_phi.get())
            self._toggle_entry(self.entry_c, self.chk_c.get())

    def _refresh_convert_button(self) -> None:
        x = self.var_input.get().strip()
        y = self.var_output.get().strip()

        input_ok = (x == MSG_CLIPBOARD_B) or Path(x).exists()
        output_ok = False
        if y:
            out = Path(_ensure_shp_extension(y))
            output_ok = out.parent.exists() and bool(out.stem)

        if input_ok and output_ok:
            self.btn_convert.state(["!disabled"])
        else:
            self.btn_convert.state(["disabled"])

    def on_load_textfile(self) -> None:
        initialdir = self.defaults.input_xy_dir if self.defaults.input_xy_dir and Path(self.defaults.input_xy_dir).exists() else ""
        filename = filedialog.askopenfilename(
            filetypes=(("txt file", "*.txt"), ("All files", "*.*")),
            initialdir=initialdir or None,
        )
        if filename:
            self.entry_input.configure(state=tk.NORMAL)
            self.var_input.set(filename)

    def on_load_clipboard(self) -> None:
        if pyperclip is None:
            messagebox.showerror(MSG_TITLE_ERROR_B, "pyperclip non è installato. Installa con: pip install pyperclip")
            return
        self.entry_input.configure(state=tk.NORMAL)
        self.var_input.set(MSG_CLIPBOARD_B)
        self.entry_input.configure(state=tk.DISABLED)

    def on_save_shapefile(self) -> None:
        initialdir = self.defaults.output_shp_dir if self.defaults.output_shp_dir and Path(self.defaults.output_shp_dir).exists() else ""
        filename = filedialog.asksaveasfilename(
            filetypes=(("Shapefile", ".shp"), ("All files", "*.*")),
            initialdir=initialdir or None,
            defaultextension=".shp",
        )
        if filename:
            self.var_output.set(_ensure_shp_extension(filename))

    def on_convert(self) -> None:
        try:
            source = self.var_input.get().strip()
            shapeout = self.var_output.get().strip()

            if not shapeout:
                messagebox.showerror(MSG_TITLE_ERROR_B, "Percorso shapefile di output mancante.")
                return

            text = read_input_text(source)
            points = parse_xy_points(text)

            if len(points) > 100:
                messagebox.showinfo(
                    MSG_TITLE_B,
                    "Attenzione: il numero di punti è > 100 (limite previsto da SSAP).\n"
                    "Dovrai modificare lo shapefile generato."
                )

            if len(points) < 2:
                messagebox.showerror(
                    MSG_TITLE_ERROR_B,
                    "Non ci sono dati utili per creare uno shapefile lineare.\n"
                    "Controlla la formattazione dei dati ASCII di input."
                )
                return

            pendenza = compute_pendenza_media(points)
            layer_values = self._collect_layer_values(pendenza)

            opts = ConvertOptions(
                layer_values=layer_values,
                use_pendenza_media=(self.chk_pendenza.get() == 1),
                falda_enabled=(self.chk_falda.get() == 1),
                falda_depth=float(self.var_falda.get()),
                bedrock_enabled=(self.chk_bedrock.get() == 1),
                bedrock_depth=float(self.var_bedrock.get()),
                phi_br=float(self.defaults.phi_br),
                c_br=float(self.defaults.c_br),
            )

            write_ssap_shapefile(shapeout, points, opts)
            messagebox.showinfo(MSG_TITLE_B, f"Procedura conclusa.\nCreato file:\n{_ensure_shp_extension(shapeout)}")

        except Exception as e:
            logging.exception("Errore conversione (B): %s", e)
            msg = f"{type(e).__name__}: {e}"
            msg = msg[: self.defaults.max_error_chars] if self.defaults.max_error_chars > 0 else msg
            messagebox.showerror(
                MSG_TITLE_ERROR_B,
                "Si è verificato un errore.\n\n"
                f"{msg}\n\n"
                f"Dettagli tecnici nel file: {LOG_PATH}"
            )

    def _collect_layer_values(self, pendenza: Optional[float]) -> LayerValues:
        use_pendenza = (self.chk_pendenza.get() == 1)

        if use_pendenza and pendenza is not None:
            phi = float(pendenza)
            self.var_phi.set(phi)
        elif self.chk_phi.get() == 1:
            phi = float(self.var_phi.get())
        else:
            phi = 0.0

        if use_pendenza:
            c = 0.0
            self.var_c.set(0.0)
        elif self.chk_c.get() == 1:
            c = float(self.var_c.get())
        else:
            c = 0.0

        cu = float(self.var_cu.get()) if self.chk_cu.get() == 1 else 0.0
        gamma = float(self.var_gamma.get()) if self.chk_gamma.get() == 1 else 0.0
        gammasat = float(self.var_gammasat.get()) if self.chk_gammasat.get() == 1 else 0.0

        return LayerValues(
            phi=round(phi, 1),
            c=round(c, 1),
            cu=round(cu, 1),
            gamma=round(gamma, 1),
            gammasat=round(gammasat, 1),
        )


# =========================
# APP UNIFICATA
# =========================

class Shp2SSAPSuite(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Shp2SSAP Suite (XY↔SHP↔SSAP) - " + str(LBL.versione))

        for ico in [Path(".") / "Icon" / "Shp2SSAP.ico", Path("Shp2SSAP.ico")]:
            if ico.exists():
                try:
                    self.iconbitmap(str(ico))
                except Exception:
                    pass
                break

        self.resizable(False, False)

        root = ttk.Frame(self, padding="8 8 8 8")
        root.grid(row=0, column=0, sticky=(tk.N, tk.W, tk.E, tk.S))
        root.columnconfigure(0, weight=1)

        nb = ttk.Notebook(root)
        nb.grid(row=0, column=0, sticky=(tk.N, tk.W, tk.E, tk.S))

        tab_xy = XY2ShpFrame(nb)
        tab_shp = Shp2SSAPFrame(nb)

        nb.add(tab_xy, text="  XY → Shapefile  ")
        nb.add(tab_shp, text="  Shapefile → files SSAP  ")

        # Status bar (semplice)
        status = ttk.Label(root, text=f"Log: {LOG_PATH}", anchor="w")
        status.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(6, 0))


def main() -> None:
    try:
        app = Shp2SSAPSuite()
        app.mainloop()
    except Exception as e:
        logging.exception("Errore avvio suite: %s", e)
        messagebox.showerror("Errore avvio", f"{type(e).__name__}: {e}\n\nLog: {LOG_PATH}")


if __name__ == "__main__":
    main()
